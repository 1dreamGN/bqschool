<?php
$templatename = array(
    'bqyj',
    //
);
$templatek = array(
    'bqyj_alias' => 'bqyj',
    'bqyj_template_name' => '冰清玉洁同学录首页',
    'bqyj_template_img' => '/Style/Other/bqyj.jpg',
    #
);
?>
