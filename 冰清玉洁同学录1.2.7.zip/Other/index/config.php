<?php
if (C('webindex') == 'Other/index/index_bqyj.php') {
    return array(
        'alias' => 'bqyj',
        'template_name' => '冰清玉洁同学录首页',
        'template_author' => '顾念',
        'template_url' => 'http://blog.qq-bq.cn/',
        'template_readme' => '冰清玉洁同学录首页/简洁大气',
        'template_img' => '/Style/Other/bqyj.jpg',
    );
}
#
?>
